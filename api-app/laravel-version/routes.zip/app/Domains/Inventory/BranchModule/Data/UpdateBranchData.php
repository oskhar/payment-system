<?php

namespace App\Domains\Inventory\BranchModule\Data;

class UpdateBranchData extends CreateBranchData {}
