<?php

namespace App\Exceptions\Common\Exceptions;

use Exception;

class UnprocessableEntityException extends Exception
{
    //
}
